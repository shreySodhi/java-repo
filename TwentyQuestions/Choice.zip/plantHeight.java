// Source: https://usaco.guide/general/io
import java.io.*;
import java.util.StringTokenizer;

public class plantHeight {
	static long [] growth;
	static long [] height;
	public static void main(String[] args) throws IOException {
		BufferedReader r = new BufferedReader(new InputStreamReader(System.in));
		PrintWriter pw = new PrintWriter(System.out);
		int n = Integer.parseInt(r.readLine());
		while(n-- > 0){
			int plants = Integer.parseInt(r.readLine());
			height = new long [plants];
			growth = new long [plants];
			StringTokenizer st = new StringTokenizer(r.readLine());
			for(int x = 0; x < plants; x++) height[x] = Long.parseLong(st.nextToken());
			st = new StringTokenizer(r.readLine());
			for(int x = 0; x < plants; x++) growth[x]  = Long.parseLong(st.nextToken());
			st = new StringTokenizer(r.readLine());

			//combine and condense here?
			for(int x = 0; x < plants; x++) swap(x, Integer.parseInt(st.nextToken())); 
			long minDays = 0;
			for(int x = 1; x < plants;x++){
				if(growth[x-1] > growth[x] && height[x] < height[x-1]){// plant order impossible
					minDays = -1;
					break;
				}
				if(height[x] > height[x-1] && growth[x-1] < growth[x]) continue; // true from start
				minDays = Math.max(minDays,(Math.abs(height[x]-height[x-1]+1)/growth[x]-growth[x-1]));	
			}
			pw.println(minDays);
		} 
		/*
		 * Make sure to include the line below, as it
		 * flushes and closes the output stream.
		 */
		pw.close();
	}
	static void swap(int oldInt, int newInt){
		long temp = height[oldInt];
		height[oldInt] = height[newInt];
		height[newInt] = height[oldInt];
		temp = growth[oldInt];
		growth[oldInt] = growth[newInt];
		growth[newInt] = temp;
	}
}
