public class test {
    public static void main(String [] args){
        StringBuilder sb = new StringBuilder();
        sb.append("\n hello" );
        sb.append("idk");
        System.out.println(sb.toString());
    }   
}
